﻿using UnityEngine;
using Xicheng.Log;

public static class ULog
{
    private static Xicheng.Log.ILogHandler _handler = new UnityLogHandler();

    private static bool _isEnableLog = true;

    public static void SetHandler(Xicheng.Log.ILogHandler handler)
    {
        _handler = handler;
    }

    /// <summary>
    /// 设置日志开关
    /// </summary>
    /// <param name="enableLog"></param>
    public static void SetLogSwitch(bool enableLog)
    {
        _isEnableLog = enableLog;
    }

    public static void Info(string message, Object context = null)
    {
        if (_isEnableLog)
        {
            _handler.Log(LogLevels.Info, message, context);
        }
    }

    public static void InfoWhite(string message, Object context = null)
    {
        Info(message, Color.white);
    }

    public static void InfoGreen(string message, Object context = null)
    {
        Info(message, Color.green);
    }

    public static void InfoCyan(string message, Object context = null)
    {
        Info(message, Color.cyan);
    }

    public static void InfoYellow(string message, Object context = null)
    {
        Info(message, Color.yellow);
    }

    public static void InfoRed(string message, Object context = null)
    {
        Info(message, Color.red);
    }


    public static void Info(string message, Color c)
    {
        if (_isEnableLog)
        {
            ColorUtility.ToHtmlStringRGB(c);
            UnityEngine.Debug.Log($"<color=#{(object)ColorUtility.ToHtmlStringRGB(c)}> {message} </color>");
        }
    }


    public static void Warning(string message, UnityEngine.Object context = null)
    {
        if (_isEnableLog)
        {
            _handler.Log(LogLevels.Warning, message, context);
        }
    }

    public static void Error(string message, UnityEngine.Object context = null)
    {
        if (_isEnableLog)
        {
            _handler.Log(LogLevels.Error, message, context);
        }
    }

    public static void Exception(System.Exception e, UnityEngine.Object context = null)
    {
        if (_isEnableLog)
            _handler.Log(LogLevels.Exception, e.Message, context);
    }
    
    /// <summary>
    /// 不受 ENABLE_LOG 控制
    /// </summary>
    public static void Debug(string message, Object context = null)
    {
        _handler.Log(LogLevels.Info, message, context);
    }
}
 