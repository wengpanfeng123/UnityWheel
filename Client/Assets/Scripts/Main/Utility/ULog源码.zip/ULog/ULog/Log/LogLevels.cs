namespace Xicheng.Log
{
    public enum LogLevels
    {
        Info,
        Warning,
        Error,
        Exception
    }
}